#!/usr/bin/env ruby
require "csv"
require "json"
require "yaml"

def fail!(message)
  raise ArgumentError, message
end

def rows(path)
  CSV.read(path, headers: true, encoding: "UTF-8").map(&:to_h)
end

input_root, _kustomize_root, result_root = ARGV
fail!("usage: independent_check.rb INPUT KUSTOMIZE RESULTS") unless result_root
contract = JSON.parse(File.read(File.join(input_root, "rollout_contract.json"), encoding: "UTF-8"))
actual = Dir.children(result_root).select { |name| File.file?(File.join(result_root, name)) }.sort
fail!("result boundary mismatch") unless actual == contract.fetch("required_result_files").sort

render_rows = rows(File.join(result_root, "render_contract.csv"))
fail!("render stage order mismatch") unless render_rows.map { |row| row["phase"] } == %w[base canary promote rollback]
contract.fetch("stages").zip(render_rows).each do |stage, row|
  fail!("render contract mismatch") unless row["image"] == stage.fetch("image") && row["partition"] == stage.fetch("partition").to_s && row["scope"] == "MANIFEST_ONLY"
  yaml = File.read(File.join(result_root, "rendered_#{stage.fetch('phase')}.yaml"), encoding: "UTF-8")
  objects = yaml.split(/^---[ \t]*$\n?/).map { |document| YAML.safe_load(document, permitted_classes: [], permitted_symbols: [], aliases: false) }.compact
  fail!("render identity mismatch") unless objects.map { |object| object["kind"] }.sort == %w[Service StatefulSet]
end

source_probes = rows(File.join(input_root, "ordinal_probes.csv"))
probe_review = rows(File.join(result_root, "probe_review.csv"))
fail!("probe row count mismatch") unless probe_review.length == source_probes.length
source_probes.zip(probe_review).each do |source, review|
  status = source["startup_pass"] == "true" && source["ready"] == "true" ? "SAMPLE_READY" : "SAMPLE_FAILED"
  fail!("probe review mismatch") unless review == source.merge("sample_status" => status, "scope" => "SUPPLIED_SAMPLE_ONLY")
end

gates = rows(File.join(result_root, "stage_gate_review.csv"))
contract.fetch("stages").reject { |stage| stage["phase"] == "base" }.zip(gates).each do |stage, gate|
  selected = stage.fetch("probe_ordinals").map { |ordinal| probe_review.find { |row| row["phase"] == stage["phase"] && row["ordinal"] == ordinal.to_s } }
  fail!("gate probe missing") if selected.any?(&:nil?)
  failed = selected.find { |row| row["sample_status"] != "SAMPLE_READY" }
  expected = failed ? "SAMPLE_HOLD" : "SAMPLE_CLEAR"
  fail!("gate result mismatch") unless gate["review_status"] == expected && gate["passing_rows"] == selected.count { |row| row["sample_status"] == "SAMPLE_READY" }.to_s && gate["scope"] == "CHECKLIST_ONLY"
end

checklist = rows(File.join(result_root, "rollback_checklist.csv"))
fail!("checklist count mismatch") unless checklist.length == contract.fetch("rollback_checklist").length
fail!("checklist execution claim") unless checklist.all? { |row| row["execution_status"] == "NOT_EXECUTED" }
summary = JSON.parse(File.read(File.join(result_root, "review_summary.json"), encoding: "UTF-8"))
%w[api_server_contacted apply_executed pod_deleted controller_state_observed pvc_state_observed rollback_executed].each do |key|
  fail!("runtime claim in #{key}") unless summary[key] == false
end
validation = JSON.parse(File.read(File.join(result_root, "validation.json"), encoding: "UTF-8"))
fail!("validation failed") unless validation["result"] == "PASS" && validation.fetch("checks").values.all?
puts "tsdb_partition_release_review independent check PASS"

#!/usr/bin/env ruby
require "csv"
require "fileutils"
require "find"
require "json"
require "open3"
require "yaml"

INPUT_FILES = ["README.md", "ordinal_probes.csv", "rollout_contract.json", "starter/statefulset.yaml"].freeze
KUSTOMIZE_FILES = [
  "base/kustomization.yaml", "base/service.yaml", "base/statefulset.yaml",
  "overlays/canary/kustomization.yaml", "overlays/canary/patch.yaml",
  "overlays/promote/kustomization.yaml", "overlays/promote/patch.yaml",
  "overlays/rollback/kustomization.yaml", "overlays/rollback/patch.yaml"
].freeze

def fail!(message)
  raise ArgumentError, message
end

def inventory(root)
  files = []
  Find.find(root) do |entry|
    next if entry == root
    fail!("symlink is not allowed: #{entry}") if File.symlink?(entry)
    files << entry.delete_prefix("#{root}/") if File.file?(entry)
  end
  files.sort
end

def write_csv(path, headers, rows)
  CSV.open(path, "wb", headers: headers, write_headers: true, row_sep: "\n") do |csv|
    rows.each { |row| csv << headers.map { |header| row.fetch(header) } }
  end
end

def write_json(path, object)
  File.binwrite(path, JSON.pretty_generate(object) + "\n")
end

def kubectl!(binary, *arguments)
  stdout, stderr, status = Open3.capture3({ "KUBECONFIG" => ENV.fetch("KUBECONFIG") }, binary, *arguments)
  fail!("kubectl failed: #{arguments.join(' ')}: #{stderr.strip}") unless status.success?
  stdout.gsub(/\r\n?/, "\n")
end

def yaml_documents(text)
  text.split(/^---[ \t]*$\n?/).map { |document| YAML.safe_load(document, permitted_classes: [], permitted_symbols: [], aliases: false) }.compact
rescue Psych::Exception => error
  fail!("invalid rendered YAML: #{error.message}")
end

input_root, kustomize_root, output_root = ARGV
fail!("usage: build_release_review.rb INPUT KUSTOMIZE OUTPUT") unless output_root
input_root = File.expand_path(input_root)
kustomize_root = File.expand_path(kustomize_root)
output_root = File.expand_path(output_root)
fail!("input boundary mismatch") unless inventory(input_root) == INPUT_FILES
fail!("Kustomize boundary mismatch") unless inventory(kustomize_root) == KUSTOMIZE_FILES
fail!("output root must be empty") if File.exist?(output_root) && (!File.directory?(output_root) || !Dir.children(output_root).empty?)

contract = JSON.parse(File.read(File.join(input_root, "rollout_contract.json"), encoding: "UTF-8"))
fail!("unsupported contract") unless contract.fetch("contract_id") == "tsdb-partition-release-review-v3"
expected_results = %w[probe_review.csv render_contract.csv rendered_base.yaml rendered_canary.yaml rendered_promote.yaml rendered_rollback.yaml review_summary.json rollback_checklist.csv stage_gate_review.csv validation.json]
fail!("result file contract mismatch") unless contract.fetch("required_result_files").sort == expected_results
stages = contract.fetch("stages")
fail!("stage order mismatch") unless stages.map { |stage| stage.fetch("phase") } == %w[base canary promote rollback]

kubectl = ENV.fetch("KUBECTL_BIN")
version = JSON.parse(kubectl!(kubectl, "version", "--client", "--output=json"))
git_version = version.fetch("clientVersion").fetch("gitVersion")
fail!("kubectl minor mismatch") unless git_version.match?(/\Av#{Regexp.escape(contract.fetch('kubectl_minor'))}\./)
manifest = contract.fetch("manifest_contract")
render_rows = []
renders = {}

stages.each do |stage|
  phase = stage.fetch("phase")
  directory = phase == "base" ? File.join(kustomize_root, "base") : File.join(kustomize_root, "overlays", phase)
  rendered = kubectl!(kubectl, "kustomize", directory)
  objects = yaml_documents(rendered)
  fail!("rendered object count mismatch for #{phase}") unless objects.length == 2
  service = objects.find { |object| object["kind"] == "Service" }
  stateful = objects.find { |object| object["kind"] == "StatefulSet" }
  fail!("rendered object kinds mismatch for #{phase}") unless service && stateful
  fail!("Service identity mismatch") unless service.dig("metadata", "name") == contract.fetch("service") && service.dig("metadata", "namespace") == contract.fetch("namespace") && service.dig("spec", "clusterIP") == "None" && service.dig("spec", "ports", 0, "port") == manifest.fetch("service_port")
  fail!("StatefulSet identity mismatch") unless stateful.dig("metadata", "name") == contract.fetch("statefulset") && stateful.dig("metadata", "namespace") == contract.fetch("namespace") && stateful.dig("spec", "serviceName") == contract.fetch("service")
  selector_closed = stateful.dig("spec", "selector", "matchLabels") == stateful.dig("spec", "template", "metadata", "labels")
  container = stateful.dig("spec", "template", "spec", "containers", 0)
  claim = stateful.dig("spec", "volumeClaimTemplates", 0)
  expected_image = stage.fetch("image")
  expected_partition = stage.fetch("partition")
  checks = [
    stateful.dig("spec", "replicas") == contract.fetch("replicas"),
    stateful.dig("spec", "podManagementPolicy") == contract.fetch("pod_management_policy"),
    stateful.dig("spec", "updateStrategy", "rollingUpdate", "partition") == expected_partition,
    stateful.dig("spec", "persistentVolumeClaimRetentionPolicy", "whenDeleted") == contract.dig("pvc_retention", "whenDeleted"),
    stateful.dig("spec", "persistentVolumeClaimRetentionPolicy", "whenScaled") == contract.dig("pvc_retention", "whenScaled"),
    stateful.dig("spec", "template", "spec", "terminationGracePeriodSeconds") == manifest.fetch("termination_grace_seconds"),
    container["image"] == expected_image,
    container.dig("startupProbe", "failureThreshold") == manifest.fetch("startup_failure_threshold"),
    container.dig("startupProbe", "periodSeconds") == manifest.fetch("startup_period_seconds"),
    container.dig("readinessProbe", "periodSeconds") == manifest.fetch("readiness_period_seconds"),
    claim.dig("metadata", "name") == manifest.fetch("claim_name"),
    claim.dig("spec", "resources", "requests", "storage") == manifest.fetch("claim_storage"),
    selector_closed
  ]
  fail!("manifest contract mismatch for #{phase}") unless checks.all?
  renders[phase] = rendered
  render_rows << {
    "phase" => phase, "image" => expected_image, "partition" => expected_partition, "replicas" => contract.fetch("replicas"),
    "pod_management_policy" => contract.fetch("pod_management_policy"), "when_deleted" => contract.dig("pvc_retention", "whenDeleted"),
    "when_scaled" => contract.dig("pvc_retention", "whenScaled"), "service_cluster_ip" => "None", "service_port" => manifest.fetch("service_port"),
    "selector_closed" => selector_closed.to_s, "startup_failure_threshold" => manifest.fetch("startup_failure_threshold"),
    "startup_period_seconds" => manifest.fetch("startup_period_seconds"), "readiness_period_seconds" => manifest.fetch("readiness_period_seconds"),
    "claim_name" => manifest.fetch("claim_name"), "claim_storage" => manifest.fetch("claim_storage"), "scope" => "MANIFEST_ONLY"
  }
end

probe_table = CSV.read(File.join(input_root, "ordinal_probes.csv"), headers: true, encoding: "UTF-8")
probe_headers = %w[phase ordinal startup_pass ready latency_ms]
fail!("probe headers mismatch") unless probe_table.headers == probe_headers
probe_rows = probe_table.map(&:to_h)
seen = {}
probe_review = probe_rows.map do |row|
  phase = row.fetch("phase")
  ordinal = Integer(row.fetch("ordinal"))
  fail!("unknown probe phase") unless %w[canary promote rollback].include?(phase)
  fail!("probe ordinal out of range") unless ordinal.between?(0, contract.fetch("replicas") - 1)
  fail!("duplicate probe") if seen[[phase, ordinal]]
  seen[[phase, ordinal]] = true
  fail!("probe booleans invalid") unless %w[true false].include?(row.fetch("startup_pass")) && %w[true false].include?(row.fetch("ready"))
  fail!("latency must be a nonnegative integer") unless row.fetch("latency_ms").match?(/\A[0-9]+\z/)
  status = row["startup_pass"] == "true" && row["ready"] == "true" ? "SAMPLE_READY" : "SAMPLE_FAILED"
  row.merge("sample_status" => status, "scope" => "SUPPLIED_SAMPLE_ONLY")
end

gate_rows = stages.reject { |stage| stage["phase"] == "base" }.map do |stage|
  phase = stage.fetch("phase")
  ordinals = stage.fetch("probe_ordinals")
  rows = ordinals.map do |ordinal|
    probe_review.find { |row| row["phase"] == phase && Integer(row["ordinal"]) == ordinal } || fail!("missing probe for #{phase}/#{ordinal}")
  end
  failed = rows.find { |row| row["sample_status"] != "SAMPLE_READY" }
  {
    "phase" => phase, "required_ordinals" => ordinals.join(";"), "sample_rows" => rows.length,
    "passing_rows" => rows.count { |row| row["sample_status"] == "SAMPLE_READY" },
    "first_failed_ordinal" => failed ? failed["ordinal"] : "", "review_status" => failed ? "SAMPLE_HOLD" : "SAMPLE_CLEAR",
    "scope" => "CHECKLIST_ONLY"
  }
end

checklist_rows = contract.fetch("rollback_checklist").map do |item|
  {
    "step" => item.fetch("step"), "action" => item.fetch("action"), "prerequisite" => item.fetch("prerequisite"),
    "evidence_to_collect" => item.fetch("evidence"), "execution_status" => "NOT_EXECUTED"
  }
end
fail!("rollback checklist steps must be contiguous") unless checklist_rows.map { |row| row["step"] } == (1..checklist_rows.length).to_a

checks = {
  "input_boundary_exact" => true, "kustomize_boundary_exact" => true, "kubectl_minor_matches" => true,
  "four_stages_render" => render_rows.length == 4, "manifest_contracts_match" => render_rows.all? { |row| row["scope"] == "MANIFEST_ONLY" },
  "probe_samples_complete" => gate_rows.sum { |row| row["sample_rows"] } == probe_review.length,
  "rollback_checklist_not_executed" => checklist_rows.all? { |row| row["execution_status"] == "NOT_EXECUTED" }
}
fail!("review checks failed") unless checks.values.all?
summary = {
  "contract_id" => contract.fetch("contract_id"), "kubectl" => git_version, "scope" => "PRE_RELEASE_REVIEW",
  "rendered_phases" => stages.map { |stage| stage.fetch("phase") }, "probe_sample_rows" => probe_review.length,
  "api_server_contacted" => false, "apply_executed" => false, "pod_deleted" => false, "controller_state_observed" => false,
  "pvc_state_observed" => false, "rollback_executed" => false
}

FileUtils.mkdir_p(output_root)
renders.each { |phase, text| File.binwrite(File.join(output_root, "rendered_#{phase}.yaml"), text) }
write_csv(File.join(output_root, "render_contract.csv"), %w[phase image partition replicas pod_management_policy when_deleted when_scaled service_cluster_ip service_port selector_closed startup_failure_threshold startup_period_seconds readiness_period_seconds claim_name claim_storage scope], render_rows)
write_csv(File.join(output_root, "probe_review.csv"), %w[phase ordinal startup_pass ready latency_ms sample_status scope], probe_review)
write_csv(File.join(output_root, "stage_gate_review.csv"), %w[phase required_ordinals sample_rows passing_rows first_failed_ordinal review_status scope], gate_rows)
write_csv(File.join(output_root, "rollback_checklist.csv"), %w[step action prerequisite evidence_to_collect execution_status], checklist_rows)
write_json(File.join(output_root, "review_summary.json"), summary)
write_json(File.join(output_root, "validation.json"), { "result" => "PASS", "checks" => checks, "controls" => { "rendered_phases" => render_rows.length, "probe_rows" => probe_review.length, "gate_rows" => gate_rows.length, "rollback_steps" => checklist_rows.length } })
puts "tsdb_partition_release_review build PASS"

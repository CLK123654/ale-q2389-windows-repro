#StatefulSet分区升级发布前复核

run_release_review.rb调用kubectl客户端版本查询和内置Kustomize，构建base、canary、promote和rollback四阶段清单。程序再把合成探针样本整理为阶段检查门，并生成尚未执行的回退检查表。

探针样本不代表StatefulSet控制器运行记录。persistentVolumeClaimRetentionPolicy只证明清单字段，不能证明PVC当前状态。

Windows11原生PowerShell命令：

    $env:ALE_INPUT_ROOT = (Resolve-Path .\input_data).Path
    $env:ALE_OUTPUT_ROOT = .\重建结果
    $env:KUBECTL_BIN = (Resolve-Path C:\Tools\kubectl.exe).Path
    ruby .\output\run_release_review.rb

正式复现不得连接集群，也不得执行commands目录中的操作员参考命令。

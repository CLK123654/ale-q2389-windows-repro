#StatefulSet分区升级发布前复核

run_release_review.rb调用kubectl客户端和内置Kustomize，构建base、canary、promote和rollback四阶段清单。程序再把探针样本整理为阶段结论，并生成待现场处理的回退检查表。

探针样本不代表StatefulSet控制器运行记录。persistentVolumeClaimRetentionPolicy只证明清单字段，不能证明PVC当前状态。

Windows11原生PowerShell命令：

    $env:ALE_INPUT_ROOT = (Resolve-Path .\input_data).Path
    $env:ALE_OUTPUT_ROOT = .\重建结果
    $env:KUBECTL_BIN = (Resolve-Path C:\Tools\kubectl.exe).Path
    ruby .\output\run_release_review.rb

commands目录中的命令留给取得审批和集群上下文的现场人员使用。

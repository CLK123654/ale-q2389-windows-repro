#输入边界

本题材料用于时序存储发布前审查，不对应真实客户、集群、工作负载、镜像仓库、Pod或PVC。

ordinal_probes.csv是发布团队提供的合成探针样本，只能用于检查阶段门规则。样本不能证明StatefulSet控制器已经更新或阻断Pod，也不能证明PVC仍处于绑定状态。

rollout_contract.json给出四阶段镜像、partition、探针样本范围和回退检查项。starter目录是待修订清单起点。

本地复现只允许kubectl客户端版本查询和kubectl kustomize。输入文件保持只读，不得连接集群，也不得执行apply、delete、rollout或get。

#材料说明

这些材料用于时序存储发布前审查，内容均为合成数据，不对应真实客户、集群、工作负载、镜像仓库、Pod或PVC。

ordinal_probes.csv是发布团队整理的探针样本，用于判断阶段状态。样本不代表StatefulSet控制器已经更新或阻断Pod，也不能说明PVC当前是否绑定。

rollout_contract.json给出四阶段镜像、partition、探针样本范围和回退检查项。starter目录保存待整理的起始清单。

发布前审查使用kubectl客户端和内置Kustomize处理本地清单。输入文件保持只读，集群操作留待审批后的维护窗执行。
